ui_print " Based on MMT Extended by Zackptg5  "
ui_print " "
ui_print "✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯"
ui_print " Bootanimation Template by @Jai_08 " 
ui_print " "
maininstall
ui_print " Installed Bootanimation successfully" 
ui_print " " 
ui_print " Follow @Cool_bootanimations for more Bootanimations "
ui_print " You can create your Bootanimation using any video"
ui_print " Just send the video in our telegram support group "
ui_print "✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯"
ui_print " "
ui_print " How to use?? "
ui_print " 1. Flash in magisk, Reboot "
ui_print " 2. Bootanimation will be successfully installed" 
ui_print " "
ui_print " You can also customize your bootanimation(optional) -" 
ui_print " Install any terminal , type su and enter" 
ui_print " Then type coolboot and enter "
ui_print " Then you can change height/width/fps"
ui_print " Changes will be applied instantly, without any reboot" 
ui_print " You can also play your bootanimation" 
ui_print " "
ui_print " If any issues, ask in our group @bootanimations_group " 
ui_print " "
ui_print "✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯✯"
ui_print " "
# This module is custom created by users using @bootanimations_bot, 
# The bot is owned by @cool_modules team 
# However we don't own any of the videos used to make bootanimations. 
# Videos are sent by users only, from different sources, 
# So if any of your personal or copyrighted videos are shared, please reach out to support group 
# And such videos and modules will be taken down asap. 
